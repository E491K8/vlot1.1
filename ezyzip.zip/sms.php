<?php
include_once ('config.php');

session_start();
    // Update the path below to your autoload.php,
    // see https://getcomposer.org/doc/01-basic-usage.md
    require_once 'vendor/autoload.php';
    use Twilio\Rest\Client;
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    $new_sid = $_SESSION['SESSION_NEW_SSID'];
    $new_otp = $_SESSION['SESSION_OTP'];
    $mail = new PHPMailer(true);

    $sid    = "AC1f9f3dbec8961cfac7a70e8318026c4e";
    $token  = "62dd8504707f76fc5a9ceb9bc02f5e75";
    $twilio = new Client($sid, $token);

    $sql = "SELECT * FROM admin WHERE email='$new_sid'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);

        $number = $row['mobile'];
        $email = $row['email'];
        $name = $row['name'];
#TWILIO-----------------------------------------------------


    $message = $twilio->messages->create(
        "$number", // to
       [
        'from' => "+14406413976",
        'body' => "OTP is $new_otp and is valid for 10 minutes. don't share your sensetive crediantials with anyone."
       ]
      );
    
      #PHPMAILER--------------------------------------------------

      try {
        $mail->SMTPDebug = 2;									
        $mail->isSMTP();										
        $mail->Host	 = 'smtp.gmail.com;';				
        $mail->SMTPAuth = true;							
        $mail->Username = 'verfiy.xpress@gmail.com';				
        $mail->Password = 'ehwxijxyjvmbdgob';					
        $mail->SMTPSecure = 'ssl';							
        $mail->Port	 = 465;
      
        $mail->setFrom('verify.xpress@gmail.com', 'XPRESS FINCORP');		
        $mail->addAddress($email);
        
        $mail->isHTML(true);								
        $mail->Subject = 'XPRESS VERIFICATION';
        $mail->Body = "$new_otp";
        $send = $mail->send();
        echo "Mail has been sent successfully!";
      } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
      }
    
    }

      if($message && $send){
        $_SESSION["SESSION_SSID"] = $new_sid;
        header("Location: verification.php");
      } else {
        echo "something went wrong!";
      }