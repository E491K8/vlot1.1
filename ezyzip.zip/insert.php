<?php

include("config.php");
date_default_timezone_set("Asia/Calcutta");

$amount = "916.69";
$email = "confict.con@gmail.com";
$utr = mt_rand(000000000, 999999999);
$txs = mt_rand(000000, 9999999);
$footprint = "VOLT F&O TXS/$txs NEFT Via NetBanking";
$tsx_id = mt_rand(00000000000, 99999999999);
$date = date('Y-m-d H:i:s');
$status = "Debit";

$sql = "INSERT INTO user_transcation (email, utr, footprint, amount, status, time, tsx_id)
VALUES ('$email', '$utr', '$footprint', '$amount', '$status', '$date', '$tsx_id')";

if(mysqli_query($conn, $sql)){
  echo "Records inserted successfully.";
} else{
  echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}

$conn->close();


?>