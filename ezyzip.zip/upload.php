<?php 

$servername = "database-1.ctsrely4bvgo.ap-south-1.rds.amazonaws.com";
$username = "admin";
$password = "pawan2244";
$dbname = "Algo";

$email = 'confict.con@gmail.com';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST["submit"])) {

    $pname = rand(1000, 10000). "-" .$_FILES["file"]["name"];
    
    $tname = $_FILES["file"]["tmp_name"];

    $upload_dir = "documents";

    move_uploaded_file($tname, $upload_dir.'/'.$pname);

    $sql = "UPDATE transact SET photo='$pname' WHERE email='$email'";

if ($conn->query($sql) === TRUE) {
  echo "Record updated successfully";

} else {
  echo "Error updating record: " . $conn->error;
}

$conn->close();
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="post" enctype="multipart/form-data">
        <input type="File" name="file">
        <input type="submit" name="submit">
    </form>
</body>
</html>