<?php
		#Browser

		function getBrowser()
{
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $browser = "N/A";

    $browsers = [
        '/msie/i' => 'Internet explorer',
        '/firefox/i' => 'Firefox',
        '/safari/i' => 'Safari',
        '/chrome/i' => 'Chrome',
        '/edge/i' => 'Edge',
        '/opera/i' => 'Opera',
        '/mobile/i' => 'Mobile browser',
    ];

    foreach ($browsers as $regex => $value) {
        if (preg_match($regex, $user_agent)) {
            $browser = $value;
        }
    }

    return $browser;
}

$brows=  getBrowser();

        #IP Address
		function getIPAddress() {  
			//whether ip is from the share internet  
			 if(!empty($_SERVER['HTTP_CLIENT_IP'])) {  
						$ip = $_SERVER['HTTP_CLIENT_IP'];  
				}  
			//whether ip is from the proxy  
			elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
						$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
			 }  
		//whether ip is from the remote address  
			else{  
					 $ip = $_SERVER['REMOTE_ADDR'];  
			 }  
			 return $ip;  
		}  
		$ip = getIPAddress();  

		// Use JSON encoded string and converts
// it into a PHP variable
$ipdat = @json_decode(file_get_contents(
    "http://www.geoplugin.net/json.gp?ip=" . $ip));

	$country = $ipdat->geoplugin_countryName;
	$city = $ipdat->geoplugin_city;

echo '<b> VOLT FINANCE FIREWELL & SECURITY<br> <br> ACCESS: DENIED<b> <br><br>{ <br>
    "IP": "' . $ip .'", <br>
    "CITY": "' . $city .'", <br>
    "COUNTRY": "' . $country .'" <br>
    "BROWSER": "' . $brows .'", <br>
    "STATUS": true, <br>
    "ERROR": [ <br>
      { <br>
       <b> Access denied your security token is invalid or expire. <br> <b>
       <b> Your IP Adrress is not valid or youre no longer avilable to this website. <b>

       <br> <br>

       Access denied! to www.https://173.168.23?ID=error?270518&&token=?{Invalid $ssid or token}&&IP=?['. $ip .' Invalid IP]
      } <br>
    ] <br>
  } <br> <b>
  

  ';

?>
