<?php

$allowed_ips = array("223.190.175.174");

?>