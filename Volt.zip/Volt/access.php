<?php

include("server/connection/config.php");
require_once 'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);

$random_encryption_bytes = random_bytes(16); // 16 bytes = 128 bits
$random_encryption_string = bin2hex($random_encryption_bytes);
$random_encryption_string = substr($random_encryption_string, 0, 128);

$link = "http://13.210.246.46/Routes/admin_route.php?key=$random_encryption_string";

if(isset($_POST['send'])) {

    $email = ( $_POST['email']);

    $sql = "SELECT * FROM admin WHERE email='$email'";

    if(mysqli_query($conn, $sql)){

              #PHPMAILER--------------------------------------------------

      try {
        $mail->SMTPDebug = 2;									
        $mail->isSMTP();										
        $mail->Host	 = 'smtp.gmail.com;';				
        $mail->SMTPAuth = true;							
        $mail->Username = 'verfiy.xpress@gmail.com';				
        $mail->Password = 'ehwxijxyjvmbdgob';					
        $mail->SMTPSecure = 'ssl';							
        $mail->Port	 = 465;
      
        $mail->setFrom('verify.xpress@gmail.com', 'XPRESS FINCORP');		
        $mail->addAddress($email);
        
        $mail->isHTML(true);								
        $mail->Subject = 'XPRESS VERIFICATION';
        $mail->Body = "Welcome Back, Your Auth Toke has been generated click the link given below! $link";
        $send = $mail->send();
        echo "Mail has been sent successfully!";
      } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
      } 

      if ($send) {
        echo "Access Permission sent your Registered email $email";
      } else {
        echo "Something went wrong";
      }
        
      } else{
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
        header("location: ../Admin/access_denied.php");
      }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="post">
    <input type="email" placeholder="Enter your email" name="email" required>
    <button type="submit" name="send">Send</button>
    </form>
</body>
</html>