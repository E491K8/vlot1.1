<?php

$random_encryption_bytes = random_bytes(16); // 16 bytes = 128 bits
$random_encryption_string = bin2hex($random_encryption_bytes);
$random_encryption_string = substr($random_encryption_string, 0, 128);


$random_bytes = random_bytes(32); // 32 bytes = 256 bits
$random_string = bin2hex($random_bytes);

header("location: ../admin/login.php?encryption=$random_encryption_string&security?=$random_string&UTF8=Routes/{%c*530}");

?>