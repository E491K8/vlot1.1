<?php

require_once("../connection/config.php");
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once "../../vendor/autoload.php";

$ref_id = $_SESSION['SESSION_ORDERID'];

//PHPMailer Object
$mail = new PHPMailer(true); //Argument true in constructor enables exceptions

$sql = "SELECT * FROM orders WHERE order_id='$ref_id'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);

    $email = $row['email'];
    $otp = $row['otp'];
    $bill = $row['bill'];
    $price = $row['price'];
    $qty = $row['quantity'];

    $msg = "Your transaction of ₹$price and $qty Quantity with the Order ID: $ref_id has been created, To complete the transaction use OTP: $otp for 2AF verification. $bill && VOLT&VVFIN FOUNDATION";

//From email address and name
try {
    $mail->SMTPDebug = 2;									
    $mail->isSMTP();										
    $mail->Host	 = 'smtp.gmail.com;';				
    $mail->SMTPAuth = true;							
    $mail->Username = 'verfiy.xpress@gmail.com';				
    $mail->Password = 'ehwxijxyjvmbdgob';					
    $mail->SMTPSecure = 'ssl';							
    $mail->Port	 = 465;
  
    $mail->setFrom('verify.xpress@gmail.com', 'XPRESS FINCORP');		
    $mail->addAddress($email);
    
    $mail->isHTML(true);								
    $mail->Subject = 'XPRESS VERIFICATION';
    $mail->Body = "$msg";
    $send = $mail->send();
    echo "Mail has been sent successfully!";
  } catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
  } 

}

  if( $send){
    $_SESSION['SESSION_ORDERID'] = $ref_id;
    header("Location: ../../pages/examples/verification.html");
  } else {
    echo "something went wrong!";
  }