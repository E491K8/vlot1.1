<?php

session_start();

include_once("../connection/config.php");
date_default_timezone_set("Asia/Calcutta");

$date = date("Y-m-d");
$otp = mt_rand(000000, 999999);
$status = "Pending";
$order_id = mt_rand(000000000, 999999999);

if (isset($_POST["purchase"])) {

	$stocks = mysqli_real_escape_string($conn, $_POST["stocks"]);
	$email = mysqli_real_escape_string($conn, $_POST["email"]);
  $ssid = mysqli_real_escape_string($conn, $_POST["ssid"]);
  $price = mysqli_real_escape_string($conn, $_POST["price"]);
	$quantity = mysqli_real_escape_string($conn, $_POST["quantity"]);
  $discription = mysqli_real_escape_string($conn, $_POST["discription"]);

  $bill = "NSE $stock Purchased/NEFT/$order_id VOLT FINANCE";

    $sql = "INSERT INTO orders (ssid, email, stock, price, quantity, otp, discription, bill, status, order_id, purchased_date) VALUES 
    ('$ssid', '$email', '$stocks', '$price', '$quantity', '$otp', '$discription', '$bill', '$status', '$order_id', '$date')";    
	  
  if ($conn->query($sql) === TRUE){  

    $_SESSION['SESSION_SSID'] = $ssid;
    $_SESSION['SESSION_ORDERID'] = $order_id;

        // COOKIE SETTINGS
        setcookie("COOKIE_ID", $ssid, time() + 3600);

        header("Location: order-otp.php");

	} 
    else {
		echo "<script>alert('Invalid SSID or Password! Please try again')</script>";
	} 
}

if($message && $send){
    $_SESSION["SESSION_SSID"] = $new_sid;
    header("Location: verification.php");
  } else {
    echo "something went wrong!";
  }



?>